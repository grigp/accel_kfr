part of 'result_bloc.dart';

class ResultEvent{}

class GetListData extends ResultEvent {}
